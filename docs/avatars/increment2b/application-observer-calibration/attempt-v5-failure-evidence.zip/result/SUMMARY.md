# Application observer calibration

**Result: application calibration failed**

This checks measurement integrity and cost on the real app. It is not memory acceptance or deployment.

Error: `ValueError('Fresh same-job native qualification failed; application not launched')`


Observer qualified for application attribution: **no**.
All prior memory failures remain. No automatic app comparison, retry, candidate promotion or 2B acceptance follows.
Download **avatar-application-calibration** for every prerequisite, workload, trace, source hash and failure.
