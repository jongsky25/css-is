# Cloud native-recorder calibration

**Result: calibration failed**

This calibrates the measurement instrument. It does not accept 2B or deploy the app.

| Slot | Mode | Duration ms | Observation bound |
| --- | --- | ---: | ---: |
| 1 | control | 3599.79 | 2.385% |
| 2 | probe | 3602.51 | 2.713% |
| 3 | probe | 3669.91 | 2.873% |
| 4 | control | 3570.72 | 2.324% |

- Slot 1: Live membership coverage failed independently of reclamation

The instrument is not qualified for application calibration.

Download **avatar-native-calibration** for every proof, raw slot, trace, audit and failure.
No failed sample is replaced and no automatic retry or application comparison follows.
