# Application observer calibration

**Result: application calibration failed**

This checks measurement integrity and cost on the real app. It is not memory acceptance or deployment.

| Slot | Mode | Navigation ms | Observation bound |
| --- | --- | ---: | ---: |
| 1 | invalid | unavailable | unavailable |
| 2 | invalid | unavailable | unavailable |
| 3 | invalid | unavailable | unavailable |
| 4 | invalid | unavailable | unavailable |

- Slot 0: Actual app types differ from proof
- Slot 1: Actual app types differ from proof
- Slot 2: Actual app types differ from proof
- Slot 3: Actual app types differ from proof

Observer qualified for application attribution: **no**.
All prior memory failures remain. No automatic app comparison, retry, candidate promotion or 2B acceptance follows.
Download **avatar-application-calibration** for every prerequisite, workload, trace, source hash and failure.
