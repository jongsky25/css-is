# Cloud native-recorder calibration

**Result: calibration passed**

This calibrates the measurement instrument. It does not accept 2B or deploy the app.

| Slot | Mode | Duration ms | Observation bound |
| --- | --- | ---: | ---: |
| 1 | control | 3869.37 | 2.851% |
| 2 | probe | 3809.72 | 2.950% |
| 3 | probe | 3715.93 | 2.827% |
| 4 | control | 3593.73 | 2.374% |


All frozen instrument gates passed on this runner condition.
Application memory measurements still require a separately frozen protocol.

Download **avatar-native-calibration** for every proof, raw slot, trace, audit and failure.
No failed sample is replaced and no automatic retry or application comparison follows.
