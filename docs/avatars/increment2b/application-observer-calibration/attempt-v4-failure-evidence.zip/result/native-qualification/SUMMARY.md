# Cloud native-recorder calibration

**Result: calibration passed**

This calibrates the measurement instrument. It does not accept 2B or deploy the app.

| Slot | Mode | Duration ms | Observation bound |
| --- | --- | ---: | ---: |
| 1 | control | 3628.26 | 2.391% |
| 2 | probe | 3700.00 | 2.769% |
| 3 | probe | 3610.34 | 3.092% |
| 4 | control | 3648.93 | 2.288% |


All frozen instrument gates passed on this runner condition.
Application memory measurements still require a separately frozen protocol.

Download **avatar-native-calibration** for every proof, raw slot, trace, audit and failure.
No failed sample is replaced and no automatic retry or application comparison follows.
