# Application observer calibration

**Result: application calibration failed**

This checks measurement integrity and cost on the real app. It is not memory acceptance or deployment.

| Slot | Mode | Navigation ms | Observation bound |
| --- | --- | ---: | ---: |
| 1 | control | 7539.98 | 4.905% |
| 2 | probe | 7617.04 | 5.655% |
| 3 | probe | 7499.49 | 5.310% |
| 4 | control | 7596.98 | 4.954% |

- Slot 1: Observation bound exceeds 5% or 250ms
- Slot 2: Observation bound exceeds 5% or 250ms

Observer qualified for application attribution: **no**.
All prior memory failures remain. No automatic app comparison, retry, candidate promotion or 2B acceptance follows.
Download **avatar-application-calibration** for every prerequisite, workload, trace, source hash and failure.
