# Cloud native-recorder calibration

**Result: calibration passed**

This calibrates the measurement instrument. It does not accept 2B or deploy the app.

| Slot | Mode | Duration ms | Observation bound |
| --- | --- | ---: | ---: |
| 1 | control | 3797.77 | 2.530% |
| 2 | probe | 3785.40 | 2.877% |
| 3 | probe | 3782.17 | 2.888% |
| 4 | control | 3658.55 | 2.576% |


All frozen instrument gates passed on this runner condition.
Application memory measurements still require a separately frozen protocol.

Download **avatar-native-calibration** for every proof, raw slot, trace, audit and failure.
No failed sample is replaced and no automatic retry or application comparison follows.
