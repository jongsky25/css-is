# Uninjected counter/GC-trace comparison

diagnostic_complete

Diagnostic only. No native/application qualification, memory acceptance or deployment.

- Slot 0 counter-only: [(6, 1, 9007), (11, 1, 6008)]
- Slot 1 trace-only: [(6, 1, 9007), (11, 1, 6008)]
- Slot 2 trace-only: [(6, 1, 9007), (11, 1, 6008)]
- Slot 3 counter-only: [(6, 1, 9007), (11, 1, 6008)]
