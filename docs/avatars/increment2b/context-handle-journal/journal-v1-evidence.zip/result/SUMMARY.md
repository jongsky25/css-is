# Snapshot-free context handle diagnostic

diagnostic_complete

Diagnostic only: no instrument/application qualification or memory acceptance.

- Slot 0 journal-only: [(6, 0), (11, 0)]
- Slot 1 journal+membership: [(6, 0), (11, 0)]
- Slot 2 journal+membership: [(6, 0), (11, 0)]
- Slot 3 journal-only: [(6, 0), (11, 0)]
