# Native-buffer handle/caller diagnostic

diagnostic_complete

Diagnostic only. No native/application qualification or memory acceptance.

- Slot 0 buffer-only: [(6, 1), (11, 1)]
- Slot 1 buffer+membership: [(6, 1), (11, 1)]
- Slot 2 buffer+membership: [(6, 1), (11, 1)]
- Slot 3 buffer-only: [(6, 1), (11, 1)]
