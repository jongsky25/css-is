# Natural-GC root diagnostic

diagnostic_complete

Perturbed root evidence only. No native/application qualification or memory acceptance.

- Slot 0 control: {'(Global handles)': 23, '(unreachable)': 2}
- Slot 1 probe: {'(Global handles)': 23, '(unreachable)': 1}
- Slot 2 probe: {'(Global handles)': 23, '(unreachable)': 1}
- Slot 3 control: {'(Global handles)': 23, '(unreachable)': 1}

No automatic calibration, retry, merge or deployment follows.
