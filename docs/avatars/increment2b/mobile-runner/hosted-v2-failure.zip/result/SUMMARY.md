# Cloud runner diagnostic

This checks the new GitHub runner. It does not accept 2B or deploy the app.

**Result: diagnostic failed**

Capture error: `ValueError('One or more fixed controls failed; retained without replacement')`

Download the **avatar-runner-diagnostic** artifact for all raw results, including failures.
The earlier failed calibration remains failed. No automatic retry or application comparison follows.
